var bananaImage, obstacleImage, obstaclesGroup, bananasGroup;
var bground, ground, backgroundImage;
var monkey, monkey_running;
var score=0; 

function preload() {
  backgroundImage=loadImage("jungle.jpg");
  
  monkey_running=loadAnimation("monkey1.png","monkey2.png","monkey3.png","monkey4.png","monkey5.png","monkey6.png","monkey7.png","monkey8.png","monkey9.png","monkey10.png");

  bananaImage=loadImage("banana.png");
  obstacleImage=loadImage("stone.png");
}

function setup() {
  createCanvas(600, 200);
  
  bground = createSprite(200,180,400,20);
  bground.addImage("bground",backgroundImage);
  bground.x = bground.width /2;
  bground.velocityX = -6;
  
  
  monkey = createSprite(50,180,20,50);
  monkey.addAnimation("monkey", monkey_running);
  monkey.scale = 0.5;
  
  ground = createSprite(200,190,400,10);
  ground.visible = false;
  
  obstaclesGroup = new Group();
  
  score = 0;
  
}

function draw() {
  background(180);
  stroke("white");
  textSize(20);
  fill("white");
  text("Score: "+ score, 500,50);
  
  if (ground.x < 0){
      ground.x = ground.width/2;
    }
  
  monkey.collide(ground);
  
  
  if(keyDown("space")) {
      monkey.velocityY = -10;
    }

    monkey.velocityY = monkey.velocityY + 0.8
  
  if (bananasGroup.isTouching(monkey)){
    score=score+2;
    BananasGroup.destroyEach();
    monkey.scale=0.2;
  }
  
  if(obstaclesGroup.isTouching(monkey)){
     monkey.scale=monkey.scale-0.2;
  }
  
  spawnBananas();
  spawnObstacles();
   
 drawSprites(); 
}

function spawnBananas() {
  if (frameCount % 60 === 0) {
    var banana = createSprite(600,80,40,10);
    banana.y = Math.round(random(50,90));
    banana.addImage(bananaImage);
    banana.scale = 0.5;
    banana.velocityX = -4;
    banana.lifetime = 300;
    bananasGroup.add(banana);
  }
}

function spawnObstacles() {
  if(frameCount % 80 === 0) {
    var stone = createSprite(600,165,10,40);
    stone.addImage(obstacleImage);
    stone.scale=0.5;
    stone.velocityX = -3;
    stone.lifetime=200;
    obstaclesGroup.add(stone);
  }
}